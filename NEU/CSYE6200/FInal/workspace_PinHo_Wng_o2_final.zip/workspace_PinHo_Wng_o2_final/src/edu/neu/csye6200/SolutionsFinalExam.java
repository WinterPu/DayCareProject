package edu.neu.csye6200;

import java.io.BufferedReader;
import java.util.Comparator;
import java.util.Scanner;
import java.util.function.Function;

import edu.neu.csye6200.api.AbstractEmployeeAPI;
import edu.neu.csye6200.api.AbstractPersonAPI;
import edu.neu.csye6200.api.AbstractPersonFactoryAPI;
import edu.neu.csye6200.api.AbstractSchoolAPI;
import edu.neu.csye6200.api.AbstractStudentAPI;
import edu.neu.csye6200.api.Employee;
import edu.neu.csye6200.api.NEU;
import edu.neu.csye6200.api.Student;
import edu.neu.csye6200.api.StudentFactory;

public class SolutionsFinalExam {

	public void controllingThreads() {
		
		/**
		 * Create and control TWO thread to alternate output of the alphabet (lowercase and uppercase).
		 */
		Thread t1 = new Thread(new Runnable() {		
			@Override
			public void run() {
				System.out.println("abcdefghijklmnopqrstuvwxyz");
			}
		});
		
		
		Thread t2 = new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
			}
		});
		
		t1.start();
		t2.start();
	}

	public void objectOrientedDesignConcepts() {
		/**
		 * Generic Programming: showAnswers method and OOD Concepts Strings
		 */
		
	}

	public void universityModel() {
		
		/** Enroll Employs **/
		AbstractSchoolAPI neu = new NEU();
//		String employList = "1,Dan,Peters,17,45.65" + "\n"
//					+ "2,Kal,Bugrara,19,35.70" + "\n"
//					+ "3,Yusuf,Ozbek,18,40.25"
//					+ "4,Jane,Smith,16,50.35";
//		Scanner scanner = new Scanner(employList);
//		String inputString = scanner.nextLine();
		neu.add(new Employee(1, "Dan", "Peters", 17, 45.65));
		neu.add(new Employee(2, "Kal", "Bugrara", 19, 35.7));
		neu.add(new Employee(3, "Yasuf", "Ozbek", 18, 40.25));
		neu.add(new Employee(4, "Jane", "Smith", 16, 50.35));
		
		/** Enroll Students **/
//		"1,Don,Smith,17,3.5"
//		"2,Adam,West,19,3.75"
//		"3,Sarah,Alan,18,3.25"
		StudentFactory stuFactory = new StudentFactory();
		neu.add(stuFactory.getObject(1, "Don", "Smith", 17, 3.5));
		neu.add(stuFactory.getObject(2, "Adam", "West", 19, 3.75));
		neu.add(stuFactory.getObject(3, "Sarah", "Alan", 18, 3.25));
		System.out.println("Show the initial");
		neu.show();
		System.out.println();
		
		
		/** Natural Order **/
		System.out.println("Sorted by natural order (Last Name)");
		neu.sortEmployees();
		neu.show();
		System.out.println();
		
		/** Employee Sorting **/
		Comparator<AbstractEmployeeAPI> hiToLow = new Comparator<AbstractEmployeeAPI>() {

			@Override
			public int compare(AbstractEmployeeAPI o1, AbstractEmployeeAPI o2) {
				return (int) (o1.getWage() - o2.getWage());
			}
		};
		
		Comparator<AbstractEmployeeAPI> lowToHigh = new Comparator<AbstractEmployeeAPI>() {

			@Override
			public int compare(AbstractEmployeeAPI o1, AbstractEmployeeAPI o2) {
				return (int) (o2.getWage() - o1.getWage());
			}
		};
		
		neu.sortEmployees(hiToLow, "Wage");
		neu.scaleEmployee(lowToHigh, new Function<AbstractEmployeeAPI, AbstractEmployeeAPI>() {
			
			@Override
			public AbstractEmployeeAPI apply(AbstractEmployeeAPI t) {
				t.setWage(t.getWage()*100);
				return t;
			}
		}, "Scale Wage");
		
		System.out.println("Sorted by Wage");
		neu.showEmployees();
		
		/** Student Sorting **/
		neu.sortRoster();
//		neu.show();
		
		Comparator<AbstractPersonAPI> gpaLowToHigh = new Comparator<AbstractPersonAPI>() {

			@Override
			public int compare(AbstractPersonAPI o1, AbstractPersonAPI o2) {
				return ((Student) o1).getGpa().compareTo(((Student) o2).getGpa());
			}
		};
		
		neu.scaleRoster(gpaLowToHigh, new Function<AbstractPersonAPI, AbstractPersonAPI>() {
			
			@Override
			public AbstractPersonAPI apply(AbstractPersonAPI s) {
				((Student) s).setGpa(((Student) s).getGpa()*100);
				return s;
			}
		} ,"Scale GPA");
		
		
		System.out.println("Sorted by GPA");
		neu.showRoster();
		
	}
	
	
}
