package edu.neu.csye6200.api;

public interface AbstractStudentAPI {
	public abstract Double getGpa();
	public abstract void setGpa(Double gpa);
}
