package edu.neu.csye6200;

public class Driver {

	public static void main(String[] args) {
		FinalExam.demo();
//		System.out.println("Hello");
	}

}
