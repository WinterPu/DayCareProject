package edu.neu.csye6200.api;

public class Employee extends AbstractEmployeeAPI{
	
	private Double wage;
	
	public Employee(Integer id, String firstN, String lastN, Integer age, Double wage) {
		super(id, firstN, lastN, age);
		this.wage = wage;
	}

	@Override
	public Double getWage() {
		return wage;
	}

	@Override
	public void setWage(Double wage) {
		this.wage = wage;
	}

	@Override
	public String toString() {
//		return "[id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + "]"
		return "Employee [wage=" + wage + "]";
	}
	
	
}
