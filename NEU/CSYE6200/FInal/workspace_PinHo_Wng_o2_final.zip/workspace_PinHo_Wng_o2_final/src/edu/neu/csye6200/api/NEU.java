package edu.neu.csye6200.api;

public class NEU extends School {

}
