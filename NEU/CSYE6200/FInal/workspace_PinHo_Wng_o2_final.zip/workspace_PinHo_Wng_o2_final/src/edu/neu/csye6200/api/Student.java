package edu.neu.csye6200.api;

public class Student extends Person implements AbstractStudentAPI {

	private Double gpa;
	
	public Student(Integer id, String firstN, String lastN, Integer age, Double gpa) {
		super(id, firstN, lastN, age);
		this.gpa = gpa;
	}

	@Override
	public Double getGpa() {
		return gpa;
	}

	@Override
	public void setGpa(Double gpa) {
		this.gpa = gpa;
	}

	@Override
	public String toString() {
		return "Student [gpa=" + gpa + "]";
	}
	
	
	
}
