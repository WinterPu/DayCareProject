package edu.neu.csye6200.api;

public class Person extends AbstractPersonAPI {

	private Integer id;
	private String firstName;
	private String lastName;
	private Integer age;
	
	public Person(Integer id, String firstN, String lastN, Integer age) {
		this.id = id;
		this.firstName = firstN;
		this.lastName = lastN;
		this.age = age;
	}
	
	
	@Override
	public Integer getId() {
		return id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String getFirstName() {
		return firstName;
	}

	@Override
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@Override
	public String getLastName() {
		return lastName;
	}

	@Override
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public Integer getAge() {
		return age;
	}

	@Override
	public void setAge(Integer age) {
		this.age = age;
	}

	@Override
	public void show() {
		this.toString();
	}


	@Override
	public String toString() {
		return "[id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + "]";
	}

}
