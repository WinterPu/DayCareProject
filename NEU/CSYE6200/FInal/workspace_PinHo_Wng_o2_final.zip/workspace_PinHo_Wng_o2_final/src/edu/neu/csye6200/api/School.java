package edu.neu.csye6200.api;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

public class School extends AbstractSchoolAPI {
	
	private List<AbstractPersonAPI> stuList;
	private List<AbstractEmployeeAPI> empList;
	
	public School() {
		stuList = new ArrayList<>();
		empList = new ArrayList<>();
	}

	@Override
	public void add(AbstractPersonAPI student) {
		stuList.add(student);
	}

	@Override
	public void add(List<AbstractPersonAPI> students) {
		for(AbstractPersonAPI p : students) {
			stuList.add(p);
		}
	}

	@Override
	public void add(AbstractEmployeeAPI employee) {
		empList.add(employee);
	}

	@Override
	public void show() {
		System.out.println("Students: ");
		System.out.println(stuList);
		System.out.println("Employees");
		System.out.println(empList);
	}

	@Override
	public void sortEmployees() {
		empList.sort(new Comparator<AbstractEmployeeAPI>() {
			@Override
			public int compare(AbstractEmployeeAPI o1, AbstractEmployeeAPI o2) {
				return o2.getLastName().compareTo(o1.getLastName());
			} 
		});
	}

	@Override
	public void sortEmployees(Comparator<AbstractEmployeeAPI> c, String title) {
//		empList.sort(c);
		empList.stream().sorted(c);
	}

	@Override
	public void scaleEmployee(Comparator<AbstractEmployeeAPI> c, Function<AbstractEmployeeAPI, AbstractEmployeeAPI> f,
			String title) {
		empList.stream().map(f).sorted(c);
	}

	@Override
	public void clearEmployees() {
		empList = new ArrayList<>();
	}

	@Override
	public void showEmployees() {
		System.out.println(empList);
	}

	@Override
	public void sortRoster() {
		stuList.sort(new Comparator<AbstractPersonAPI>() {
			@Override
			public int compare(AbstractPersonAPI o1, AbstractPersonAPI o2) {
				return ((Student) o2).getLastName().compareTo(((Student) o1).getLastName());
			}
		});
	}

	@Override
	public void sortRoster(Comparator<AbstractPersonAPI> c, String title) {
//		stuList.sort(c);
		stuList.stream().sorted(c);
	}

	@Override
	public void scaleRoster(Comparator<AbstractPersonAPI> c, Function<AbstractPersonAPI, AbstractPersonAPI> f,
			String title) {
		stuList.stream().map(f).sorted(c);
	}

	@Override
	public void clearRoster() {
		stuList = new ArrayList<>();
	}

	@Override
	public void showRoster() {
		System.out.println(stuList);
	}

}
