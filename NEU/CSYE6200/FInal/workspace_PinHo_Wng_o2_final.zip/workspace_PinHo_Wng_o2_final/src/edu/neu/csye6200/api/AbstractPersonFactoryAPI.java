package edu.neu.csye6200.api;

public abstract class AbstractPersonFactoryAPI {
	public abstract AbstractPersonAPI getObject();
	public abstract AbstractPersonAPI getObject(String csvData);
}
