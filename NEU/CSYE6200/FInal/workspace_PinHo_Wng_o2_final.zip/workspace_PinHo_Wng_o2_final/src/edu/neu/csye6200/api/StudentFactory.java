package edu.neu.csye6200.api;

public class StudentFactory extends AbstractPersonFactoryAPI {

	
	public AbstractPersonAPI getObject(Integer id, String firstN, String lastN, Integer age, Double gpa) {
		return new Student(id, firstN, lastN, age, gpa);
	}

	@Override
	public AbstractPersonAPI getObject(String csvData) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AbstractPersonAPI getObject() {
		// TODO Auto-generated method stub
		return null;
	}

}
