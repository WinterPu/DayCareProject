package edu.neu.csye6200.api;

public abstract class AbstractEmployeeAPI extends Person {
	
	public AbstractEmployeeAPI(Integer id, String firstN, String lastN, Integer age) {
		super(id, firstN, lastN, age);
	}
	public abstract Double getWage();
	public abstract void setWage(Double wage);
}
