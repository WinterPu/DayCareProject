package neu.edu.csye6200;

public class Driver {
	public static void main(String[] args) {
		ComputerShop cs = new ComputerShop();
		cs.display();
	}
}
