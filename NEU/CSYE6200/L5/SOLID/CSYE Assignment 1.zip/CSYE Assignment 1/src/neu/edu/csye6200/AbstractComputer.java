package neu.edu.csye6200;

// this is for an abstract concept of computing machine
public abstract class AbstractComputer {
	public abstract void computerName();
}
