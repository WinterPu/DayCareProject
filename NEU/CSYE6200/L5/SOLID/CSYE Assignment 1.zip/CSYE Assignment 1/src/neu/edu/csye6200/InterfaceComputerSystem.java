package neu.edu.csye6200;

public interface InterfaceComputerSystem {
  public void computerSystem();
}
