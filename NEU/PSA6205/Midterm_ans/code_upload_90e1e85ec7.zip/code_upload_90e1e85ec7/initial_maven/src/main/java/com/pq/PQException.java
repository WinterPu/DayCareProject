  /*
 * Copyright (c) 2017. Phasmid Software
 */

/*/////////////////////////////////////////////////////////////////

    DO NOT MODIFY THIS FILE
    
*//////////////////////////////////////////////////////////////////

package com.pq;

class PQException extends Exception {
    public PQException(String msg) {
        super(msg);
    }
}
